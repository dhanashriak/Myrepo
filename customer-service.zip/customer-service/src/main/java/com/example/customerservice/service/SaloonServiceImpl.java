package com.example.customerservice.service;


import com.example.customerservice.dto.Saloons;
import com.example.customerservice.repository.SaloonRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SaloonServiceImpl implements SaloonService {

    private final SaloonRepository saloonRepository;

    public SaloonServiceImpl(SaloonRepository saloonRepository) {
        this.saloonRepository = saloonRepository;
    }

    @Override
    public Saloons saveSaloon(Saloons saloon) {
        return saloonRepository.save(saloon);
    }

    @Override
    public List<Saloons> getAllSaloons() {
        return saloonRepository.findAll();
    }

    @Override
    public Saloons getSaloonById(int id) {
        return saloonRepository.findById(id).orElse(null);
    }

    @Override
    public void deleteSaloon(int id) {
        saloonRepository.deleteById(id);
    }
}
