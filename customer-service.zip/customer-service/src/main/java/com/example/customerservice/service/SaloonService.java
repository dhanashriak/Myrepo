package com.example.customerservice.service;



import java.util.List;

import com.example.customerservice.dto.Saloons;

public interface SaloonService {
    Saloons saveSaloon(Saloons saloon);
    List<Saloons> getAllSaloons();
    Saloons getSaloonById(int id);
    void deleteSaloon(int id);
}
