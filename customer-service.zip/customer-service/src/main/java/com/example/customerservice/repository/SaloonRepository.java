package com.example.customerservice.repository;





import org.springframework.data.mongodb.repository.MongoRepository;

import com.example.customerservice.dto.Saloons;

public interface SaloonRepository extends MongoRepository<Saloons, Integer> {
	
	
}
