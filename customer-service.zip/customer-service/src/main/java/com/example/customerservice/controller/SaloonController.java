package com.example.customerservice.controller;




import org.springframework.web.bind.annotation.*;

import com.example.customerservice.dto.Saloons;
import com.example.customerservice.service.SaloonService;

import java.util.List;

@RestController
@RequestMapping("/api/saloons")
public class SaloonController {

    private final SaloonService saloonService;

    public SaloonController(SaloonService saloonService) {
        this.saloonService = saloonService;
    }

    @PostMapping
    public Saloons createSaloon(@RequestBody Saloons saloon) {
        return saloonService.saveSaloon(saloon);
    }

    @GetMapping
    public List<Saloons> getAllSaloons() {
        return saloonService.getAllSaloons();
    }

    @GetMapping("/{id}")
    public Saloons getSaloonById(@PathVariable int id) {
        return saloonService.getSaloonById(id);
    }

    @DeleteMapping("/{id}")
    public void deleteSaloon(@PathVariable int id) {
        saloonService.deleteSaloon(id);
    }
}
