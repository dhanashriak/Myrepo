package com.example.customerservice.config;

import com.example.customerservice.dto.Saloons;
import com.example.customerservice.model.Customer;

import com.example.customerservice.repository.CustomerRepository;
import com.example.customerservice.repository.SaloonRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.InputStream;
import java.util.List;

@Configuration
public class DataLoader {

    @Bean
    CommandLineRunner loadData(CustomerRepository customerRepository, SaloonRepository saloonRepository) {
        return args -> {
            ObjectMapper mapper = new ObjectMapper();

            // Load Customers
            InputStream customerStream = getClass().getResourceAsStream("/customers_sample.json");
            if (customerStream != null) {
                List<Customer> customers = mapper.readValue(customerStream, new TypeReference<List<Customer>>() {});
                customerRepository.saveAll(customers);
                System.out.println("✔ Customers loaded into MongoDB");
            } else {
                System.out.println("⚠ customers_sample.json not found in resources.");
            }

            // Load Saloons
            InputStream saloonStream = getClass().getResourceAsStream("/saloons_sample.json");
            if (saloonStream != null) {
                List<Saloons> saloons = mapper.readValue(saloonStream, new TypeReference<List<Saloons>>() {});
                saloonRepository.saveAll(saloons);
                System.out.println("✔ Saloons loaded into MongoDB");
            } else {
                System.out.println("⚠ saloons_sample.json not found in resources.");
            }
        };
    }
}
