package com.example.customerservice.model;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.example.customerservice.dto.Address;

import java.math.BigInteger;

@Document(collection = "customers")
public class Customer {

    @Id
    private int customerId;
    private String name;
    private String emailId;
    private BigInteger mobileNumber;
    private Address address;

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmailId() { return emailId; }
    public void setEmailId(String emailId) { this.emailId = emailId; }

    public BigInteger getMobileNumber() { return mobileNumber; }
    public void setMobileNumber(BigInteger mobileNumber) { this.mobileNumber = mobileNumber; }

    public Address getAddress() { return address; }
    public void setAddress(Address address) { this.address = address; }
}
