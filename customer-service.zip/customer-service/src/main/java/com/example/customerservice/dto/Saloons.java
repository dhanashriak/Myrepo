package com.example.customerservice.dto;



import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.example.customerservice.model.Customer;

import java.math.BigInteger;
import java.util.List;

@Document(collection = "saloons")
public class Saloons {

    @Id
    private int saloonId;
    private String name;
    private Address address;
    private BigInteger phoneNumber;
    private List<Customer> customerList;

    public int getSaloonId() { return saloonId; }
    public void setSaloonId(int saloonId) { this.saloonId = saloonId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Address getAddress() { return address; }
    public void setAddress(Address address) { this.address = address; }

    public BigInteger getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(BigInteger phoneNumber) { this.phoneNumber = phoneNumber; }

    public List<Customer> getCustomerList() { return customerList; }
    public void setCustomerList(List<Customer> customerList) { this.customerList = customerList; }
}
